from django.db import models

# Create your models here.
class Course(models.Model):
    course_name =models.CharField(max_length=50)

    def __str__(self):
        return f"{self.course_name}"

class City(models.Model):
    city_name = models.CharField(max_length=50)

    def __str__(self):
        return f"{self.city_name}"

class Student(models.Model):
    Student_Name = models.CharField(max_length=50)
    Student_Number = models.BigIntegerField()
    Student_Email = models.CharField(max_length=50)
    Student_City = models.ForeignKey(City, on_delete = models.CASCADE) # When we delete parent table data the related data which is present in child table also delete
    Student_Course = models.ForeignKey(Course, on_delete=models.SET_NULL,null=True)
    Student_Fees = models.IntegerField()

# class Subscribe(models.Model):


