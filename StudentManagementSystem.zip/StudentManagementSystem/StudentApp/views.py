from django.contrib.auth import authenticate, login,logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.db.models import Q
from django.shortcuts import render, redirect
from django.views.decorators.cache import never_cache

from StudentApp.models import City, Course, Student


# Create your views here
@login_required
@never_cache
def insert_fun(request):
    if request.method == 'POST':
        s1 = Student()
        s1.Student_Name = request.POST['txtname']
        s1.Student_Number = int(request.POST['txtphno'])
        s1.Student_Email = request.POST['txtemail']
        s1.Student_Fees = int(request.POST['txtfees'])
        s1.Student_Course = Course.objects.get(course_name=request.POST['ddlcourse'])
        s1.Student_City = City.objects.get(city_name=request.POST['ddlcity'])
        s1.save()
        return render(request,'insert.html', {'msg':'Record Successfully Inserted'})

    else:
        city = City.objects.all()
        courses  = Course.objects.all()
        return render(request,'insert.html', {'CityData': city, 'CourseData': courses})

@login_required
def display_fun(request):
    s1 = Student.objects.all()
    return render(request,'display.html',{'data': s1})

@login_required
@never_cache
def update_fun(request,id):
    s1 = Student.objects.get(id=id)
    city = City.objects.all()
    courses = Course.objects.all()
    if request.method =='POST':
        s1.Student_Name = request.POST['txtname']
        s1.Student_Number = int(request.POST['txtphno'])
        s1.Student_Email = request.POST['txtemail']
        s1.Student_Fees = int(request.POST['txtfees'])
        s1.Student_Course = Course.objects.get(course_name=request.POST['ddlcourse'])
        s1.Student_City = City.objects.get(city_name=request.POST['ddlcity'])
        s1.save()
        return render(request,'update.html', {'data':s1,'CityData':city,'CourseData':courses,'msg': ' '})
    else:
        return render(request,'update.html', {'data':s1,'CityData':city,'CourseData':courses})

@login_required
@never_cache
def delete_fun(request,id):
    s1 = Student.objects.get(id=id)
    s1.delete()
    return redirect('display')


def login_fun(request):
    if request.method == 'POST':
        u_name = request.POST['txtuname']
        u_pswd = request.POST['txtpwrd']
        user = authenticate(username=u_name,password=u_pswd)
        if user is not None:
            if user.is_superuser:
                login(request, user)
                request.session['Name'] = u_name
                return redirect('home')
        else:
            return render(request, 'login.html',{'msg': 'Enter a valid Username and Password'})
    else:
        return render(request,'login.html',{'msg':''})


def reg_fun(request):
    if request.method == 'POST':
        u_name = request.POST['txtuname']
        u_email = request.POST['emilid']
        u_password = request.POST['txtpwrd']

        u2= User.objects.filter(Q(username=u_name),Q(email=u_email)).exists()
        if u2:
            return render(request, 'register.html',{'msg': 'User already exist, Please go to login'})
        else:
            u1 = User.objects.create_superuser(username=u_name, password=u_password, email=u_email)
            u1.save()
            return redirect('log')
    else:
        return render(request,'register.html',{'msg': ''})
@login_required
@never_cache

def home_fun(request):

    return render(request,'home.html',{'data':request.session['Name']})

def logout_fun(request):
    logout(request)
    return redirect('log')


def subscribe_fun(request):
    return render(request,'subscribe.html')


def contact_fun(request):
    return render(request,'contact.html')