from django.urls import path, re_path

from StudentApp import views

from django.conf import settings
from django.conf.urls.static import static

from django.urls import path
from django.views.static import serve
from django.conf import settings

urlpatterns = [
    path('', views.login_fun, name='log'),  # Redirect to Login page
    path('regdata', views.reg_fun, name='reg'),  # Redirect to register page
    path('insert',views.insert_fun, name = 'insert'), # Insering Data
    path('display',views.display_fun, name = 'display'), # Displaying data
    path('update/<int:id>',views.update_fun, name = 'update'), # Updating data
    path('del/<int:id>',views.delete_fun, name = 'del'), # Deleteing data
    path('home',views.home_fun, name = 'home'), # redirect to home.html
    path('logout', views.logout_fun, name='logout'),  # Logout URL
    path('subscribe', views.subscribe_fun, name='subscribe'),  # subscribe URL
    path('contact', views.contact_fun, name='contact'),  # Logout URL
    re_path(r'^static/(?P<path>.*)$', serve, {'document_root': settings.STATIC_ROOT}),

]
urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)

